# CI/CD Agent Prompt

Design a safe GitHub Actions pipeline with rollback support and zero downtime.

Constraints:
- Docker & Docker Compose
- SSH deploy
- Debian 12
